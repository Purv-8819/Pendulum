package dev.purv.pendulum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PendulumApplication {

	public static void main(String[] args) {
		SpringApplication.run(PendulumApplication.class, args);
	}

}
