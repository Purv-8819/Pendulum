package dev.purv.pendulum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PendulumApplicationTests {

	@Test
	void contextLoads() {
	}

}
